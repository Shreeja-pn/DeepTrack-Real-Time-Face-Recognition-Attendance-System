import os
import smtplib
from email.mime.text import MIMEText

SENDER = os.getenv("EMAIL_SENDER")
APP_PASS = os.getenv("EMAIL_APP_PASSWORD")

def send_email(to_email, subject, body):
    """Send an email via Gmail."""
    if not SENDER or not APP_PASS:
        print("❌ Email sender credentials not set.")
        return False

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = SENDER
    msg["To"] = to_email

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as s:
            s.starttls()
            s.login(SENDER, APP_PASS)
            s.sendmail(SENDER, [to_email], msg.as_string())
        print(f"📧 Email sent to {to_email}")
        return True
    except Exception as e:
        print("❌ Failed to send email:", e)
        return False
