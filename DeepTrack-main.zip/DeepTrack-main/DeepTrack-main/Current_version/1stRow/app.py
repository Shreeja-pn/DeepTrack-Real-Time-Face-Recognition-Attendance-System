import cv2
import numpy as np
import json
import os
import pandas as pd
from ultralytics import YOLO
from deepface import DeepFace
from datetime import datetime
import logging
import time
from email_utils import send_email  # ✅ Make sure this file exists and works

# ------------------ LOAD ROI ------------------ #
def load_roi(filename="roi_config.json"):
    try:
        with open(filename, "r") as f:
            data = json.load(f)
            if "roi" in data:
                return np.array(data["roi"], np.int32)
            elif "matrix" in data and "size" in data:
                return data, "perspective"
    except FileNotFoundError:
        print("ROI file not found")
        return None

polygon_roi = load_roi()
if polygon_roi is None:
    print("⚠️ ROI not found! Please run CreateRoi.py first.")
    exit()
else:
    polygon_roi = np.array(polygon_roi, dtype=np.int32).reshape((-1, 1, 2))
    print("✅ ROI loaded:", polygon_roi)

# ------------------ YOLO MODEL ------------------ #
model = YOLO("yolov11n-face.pt")

# ------------------ KNOWN FACES ------------------ #
KNOWN_FACES_DIR = "known_faces"
os.makedirs(KNOWN_FACES_DIR, exist_ok=True)

attendance_file = "attendance.csv"
attendance_today = set()
today_date = datetime.now().strftime("%Y-%m-%d")

# ------------------ LOAD EXISTING ATTENDANCE ------------------ #
if os.path.exists(attendance_file):
    try:
        df = pd.read_csv(attendance_file)
        if "Date" in df.columns and "Name" in df.columns:
            today_df = df[df["Date"] == today_date]
            attendance_today = set(today_df["Name"].values)
            print(f"📄 Loaded attendance for {today_date}: {attendance_today}")
        else:
            print("CSV missing 'Date' or 'Name' columns. Resetting attendance.")
    except Exception as e:
        print(f"Error reading attendance file: {e}")

# ------------------ VIDEO SOURCE ------------------ #
VIDEO_PATH = "raw_footage_first_row.mp4"
if os.path.exists(VIDEO_PATH):
    cap = cv2.VideoCapture(VIDEO_PATH)
    print(f"🎥 Using video file: {VIDEO_PATH}")
else:
    cap = cv2.VideoCapture(0)
    print("📷 Using webcam instead")

fps = cap.get(cv2.CAP_PROP_FPS)
if fps == 0 or np.isnan(fps):
    fps = 30  # fallback if webcam doesn't return FPS
target_interval = 0.4
frame_skip = int(fps * target_interval)

# ------------------ GLOBAL VARIABLES ------------------ #q
cropped_faces_display = {}
face_embeddings_cache = set()
frame_count = 0

# ------------------ STUDENT EMAILS ------------------ #
student_emails = {
    "shreeja": "shreeja.raju.12@gmail.com",
    "nirmala": "nirmalapadmaraja2001@gmail.com",
    "keerthiga":"keerthiga.neelakandan@gmail.com",
    "guide":"balaganesh.n@vit.ac.in"
}
teacher_email = "shreeja.pn2021@vitstudent.ac.in"

# ------------------ MARK ATTENDANCE ------------------ #
def mark_attendance(name, face_crop):
    global attendance_today
    print(f"➡️ mark_attendance() called for '{name}'")
    current_time = datetime.now().strftime("%H:%M:%S")

    if name not in attendance_today:
        attendance_today.add(name)
        new_entry = pd.DataFrame({"Name": [name], "Date": [today_date], "Time": [current_time]})

        write_header = not os.path.exists(attendance_file) or os.path.getsize(attendance_file) == 0
        print("📁 Writing to:", os.path.abspath(attendance_file))
        new_entry.to_csv(attendance_file, mode="a", header=write_header, index=False)
        print(f"✅ Attendance marked in CSV for {name}")

        print(f"Marking attendance for {name}")
        print(f"Attendance today before: {attendance_today}")
        print("Attendance CSV path:", os.path.abspath(attendance_file))



        # ✅ Send email to student
        if name in student_emails:
            print(f"📧 Sending email to {student_emails[name]}...")
            try:
                send_email(
                    to_email=student_emails[name],
                    subject="Attendance Marked - DeepTrack System",
                    body=f"Hello {name.capitalize()},\n\nYou have been successfully marked present on {today_date} at {current_time}.\n\n- DeepTrack Attendance System"
                )
                print(f"✅ Email sent to {student_emails[name]}")
            except Exception as e:
                print(f"❌ Failed to send student email: {e}")
        else:
            print(f"⚠️ No email found for '{name}' — skipping student mail")
    else:
        print(f"ℹ️ {name} already marked present today")
        print(f"Attempting to send email to: {student_emails.get(name)}")


# ------------------ POLYGON CHECK ------------------ #
def is_inside_polygon(x, y, polygon):
    return cv2.pointPolygonTest(polygon, (x, y), False) >= 0

# ------------------ MAIN LOOP ------------------ #
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        print("🚫 End of video or no frame captured")
        break

    frame_count += 1
    if frame_count % frame_skip != 0:
        continue

    x, y, w, h = cv2.boundingRect(polygon_roi)
    roi_cropped_frame = frame[y:y+h, x:x+w]
    results = model(roi_cropped_frame)

    for result in results:
        for box in result.boxes:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            x1 += x; x2 += x; y1 += y; y2 += y

            face_center_x = (x1 + x2) // 2
            face_center_y = (y1 + y2) // 2

            if is_inside_polygon(face_center_x, face_center_y, polygon_roi):
                face_crop = frame[y1:y2, x1:x2]
                if face_crop.size == 0:
                    continue

                try:
                    face_id_key = f"{x1}_{y1}_{x2}_{y2}_{frame_count}"
                    if face_id_key not in face_embeddings_cache:
                        print("🔍 Running DeepFace.find()...")
                        verification = DeepFace.find(
                            img_path=face_crop,
                            db_path=KNOWN_FACES_DIR,
                            model_name="ArcFace",
                            enforce_detection=False
                        )
                        if isinstance(verification, list):
                            print("DeepFace result:", verification[0])

                        if isinstance(verification, list) and len(verification) > 0 and not verification[0].empty:
                            best_match = verification[0].iloc[0]
                            person_name = os.path.basename(best_match["identity"]).split(".")[0].lower().strip()
                            print(f"✅ Detected match: {person_name}")

                            face_embeddings_cache.add(face_id_key)
                            mark_attendance(person_name, face_crop)

                            cv2.putText(frame, f"{person_name}", (x1, y1 - 10),
                                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                        else:
                            print("⚠️ No match found for face")
                except Exception as e:
                    logging.error(f"Face Recognition Error: {str(e)}")

                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

    cv2.polylines(frame, [polygon_roi], isClosed=True, color=(255, 0, 0), thickness=10)
    cv2.imshow("Face Recognition Attendance", frame)

    key = cv2.waitKey(int(1000 / fps))
    if key & 0xFF == ord("q"):
        break

# ------------------ SEND SUMMARY TO TEACHER ------------------ #
try:
    df = pd.read_csv(attendance_file)
    today_df = df[df["Date"] == today_date]
    present = len(today_df)
    total_students = len(student_emails)
    absent = total_students - present

    summary = f"Attendance Summary for {today_date}\n\nTotal Students: {total_students}\nPresent: {present}\nAbsent: {absent}\n\n- DeepTrack Attendance System"
    print("📨 Sending summary email to teacher...")
    send_email(teacher_email, f"Attendance Summary - {today_date}", summary)
    print("✅ Teacher summary email sent successfully!")
except Exception as e:
    print("❌ Failed to send teacher summary:", e)

cap.release()
cv2.destroyAllWindows()
