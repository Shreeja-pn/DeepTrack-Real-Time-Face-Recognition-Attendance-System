# test_send_email.py
import os
from email.mime.text import MIMEText
import smtplib

SENDER = os.getenv("EMAIL_SENDER")
APP_PASS = os.getenv("EMAIL_APP_PASSWORD")
TO = os.getenv("TEST_RECEIVER") or SENDER  # send to yourself if no TEST_RECEIVER



if not SENDER or not APP_PASS:
    print("ERROR: EMAIL_SENDER or EMAIL_APP_PASSWORD not set in environment.")
    raise SystemExit(1)
msg = MIMEText("This is a test email from the Attendance system.\n\nIf you get this, SMTP works.")
msg["Subject"] = "Test Email - Attendance System"
msg["From"] = SENDER
msg["To"] = TO



try:
    with smtplib.SMTP("smtp.gmail.com", 587) as s:
        s.ehlo()
        s.starttls()
        s.login(SENDER, APP_PASS)
        s.sendmail(SENDER, [TO], msg.as_string())
    print(f"✅ Test email sent to {TO}")
except Exception as e:
    print("❌ Failed to send test email:", e)


